
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { json } from 'express';
import { authRouter } from './routes/auth.js';
import { settingsRouter } from './routes/settings.js';
import { locationRouter } from './routes/location.js';
import { votesRouter } from './routes/votes.js';
import { feedRouter } from './routes/feed.js';

const app = express();
app.use(helmet());
app.use(cors());
app.use(json());

app.get('/health', (_req, res) => res.json({ ok: true }));

app.use('/v1/auth', authRouter);
app.use('/v1/settings', settingsRouter);
app.use('/v1/location', locationRouter);
app.use('/v1/posts', votesRouter);
app.use('/v1/feed', feedRouter);

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`API ready on http://localhost:${port}`));
