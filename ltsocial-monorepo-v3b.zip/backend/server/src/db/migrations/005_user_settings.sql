
CREATE TABLE IF NOT EXISTS core.user_settings (
  user_id BIGINT PRIMARY KEY,
  up_emoji TEXT NOT NULL DEFAULT '👍',
  down_emoji TEXT NOT NULL DEFAULT '👎',
  font_url TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS core.settings_change_log (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL,
  field TEXT NOT NULL CHECK (field IN ('voting')),
  changed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE OR REPLACE VIEW core.voting_changes_last_year AS
SELECT user_id, COUNT(*) AS changes
FROM core.settings_change_log
WHERE field='voting' AND changed_at >= now() - INTERVAL '365 days'
GROUP BY user_id;
