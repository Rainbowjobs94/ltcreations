
import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db/db.js';

export const authRouter = Router();

const SignupSchema = z.object({
  email: z.string().email(),
  app: z.enum(['LT','MN','SU']),
  track: z.enum(['family','fan','influencer']),
  ageBand: z.enum(['kid','teen_13_15','teen_16_17','adult_18_plus']),
  guardianInviteCode: z.string().optional(),
  voteStyle: z.object({
    upEmoji: z.string().min(1).max(4).default('👍'),
    downEmoji: z.string().min(1).max(4).default('👎'),
    fontUrl: z.string().url().optional()
  }).optional()
});

authRouter.post('/signup', async (req, res) => {
  const p = SignupSchema.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: p.error.flatten() });
  const { app, track, ageBand, guardianInviteCode, voteStyle, email } = p.data;

  // Minor gating
  const isMinor = ageBand === 'kid' || ageBand.startsWith('teen');
  if (isMinor && !guardianInviteCode) {
    return res.status(403).json({ error: 'Guardian approval required for minors (guardianInviteCode missing).' });
  }

  // Demo user insert (idempotent upsert by email)
  await query(`CREATE TABLE IF NOT EXISTS core.users_minimal (id BIGSERIAL PRIMARY KEY, email TEXT UNIQUE NOT NULL)`);
  const ins = await query<{id:number}>(`INSERT INTO core.users_minimal (email) VALUES ($1) ON CONFLICT (email) DO UPDATE SET email=EXCLUDED.email RETURNING id`, [email]);
  const userId = ins.rows[0].id;

  // Seed user_settings with chosen voteStyle
  await query(`INSERT INTO core.user_settings (user_id, up_emoji, down_emoji, font_url)
               VALUES ($1,$2,$3,$4)
               ON CONFLICT (user_id) DO UPDATE SET up_emoji=EXCLUDED.up_emoji, down_emoji=EXCLUDED.down_emoji, font_url=EXCLUDED.font_url, updated_at=now()`,
               [userId, voteStyle?.upEmoji || '👍', voteStyle?.downEmoji || '👎', voteStyle?.fontUrl || null]);

  const appBase = app === 'LT' ? 'http://localhost:4200'
                 : app === 'MN' ? 'exp://localhost:19000'
                 : 'http://localhost:4300';
  let segment = track;
  if (track === 'family' && (ageBand.startsWith('teen'))) segment = 'teen';
  if (track === 'family' && ageBand === 'kid') segment = 'kid';

  res.json({
    userId, app, track, ageBand,
    nextAction: isMinor ? 'guardian_approval' : 'verify_email',
    redirectUrl: `${appBase}/onboard/${segment}`,
    voteStyle: voteStyle || { upEmoji: '👍', downEmoji: '👎' }
  });
});
