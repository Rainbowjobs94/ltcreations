
import { Router } from 'express';
export const locationRouter = Router();

// Hotspots aggregated from public posts; 'hours' window selects timeframe
locationRouter.get('/public-hotspots', (req, res) => {
  const hours = Math.max(1, Math.min(24*30, Number(req.query.hours) || 168)); // 24h, 7d default, up to 30d
  // Stubbed demo data; in production filter by created_at >= now()-interval 'hours'
  const items = [
    { lat: 40.7128, lng: -74.0060, weight: hours >= 24 ? 5 : 2, label: 'NYC' },
    { lat: 34.0522, lng: -118.2437, weight: hours >= 168 ? 3 : 1, label: 'LA' },
    { lat: 41.8781, lng: -87.6298, weight: hours >= 720 ? 2 : 1, label: 'Chicago' }
  ];
  res.json({ items, hours });
});

locationRouter.get('/status', (_req, res) => res.json({ sharing: false, lastUpdated: null }));
locationRouter.post('/start', (_req, res) => res.status(204).send());
locationRouter.post('/stop', (_req, res) => res.status(204).send());
