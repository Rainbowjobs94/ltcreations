
import { Router } from 'express';
import { z } from 'zod';
export const votesRouter = Router();
const VoteSchema = z.object({ direction: z.number().refine(v=>v===1 || v===-1) });
votesRouter.put('/:postId/vote', (req,res)=>{
  const p=VoteSchema.safeParse(req.body);
  if(!p.success) return res.status(400).json({error:p.error.flatten()});
  res.status(204).send();
});
votesRouter.delete('/:postId/vote', (_req,res)=> res.status(204).send());
