
import { Router } from 'express';
export const feedRouter = Router();
feedRouter.get('/', (_req,res)=> res.json({ items:[ { id:'p1', snippet:'Hello', ups:1, downs:0 }, { id:'p2', snippet:'World', ups:2, downs:1 } ] }));
