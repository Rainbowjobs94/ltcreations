
import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db/db.js';

export const settingsRouter = Router();

// Use x-user-id header for demo (in prod, read from auth)
function getUserId(req: any): number { return Number(req.headers['x-user-id'] || 1); }

const VotingPrefSchema = z.object({
  upEmoji: z.string().min(1).max(4),
  downEmoji: z.string().min(1).max(4),
  fontUrl: z.string().url().optional()
});

settingsRouter.get('/voting', async (req, res) => {
  const userId = getUserId(req);
  const current = await query<{up_emoji:string,down_emoji:string,font_url:string|null}>(
    `SELECT up_emoji, down_emoji, font_url FROM core.user_settings WHERE user_id=$1`, [userId]
  );
  const up = current.rows[0]?.up_emoji ?? '👍';
  const down = current.rows[0]?.down_emoji ?? '👎';
  const font = current.rows[0]?.font_url ?? null;

  const changes = await query<{changes:number}>(
    `SELECT COALESCE((SELECT changes FROM core.voting_changes_last_year WHERE user_id=$1),0) AS changes`, [userId]
  );
  const used = changes.rows[0]?.changes ?? 0;
  return res.json({ upEmoji: up, downEmoji: down, fontUrl: font, changesRemainingThisYear: Math.max(0, 2 - used) });
});

settingsRouter.put('/voting', async (req, res) => {
  const userId = getUserId(req);
  const p = VotingPrefSchema.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: p.error.flatten() });

  const { rows } = await query<{changes:number}>(`SELECT COALESCE((SELECT changes FROM core.voting_changes_last_year WHERE user_id=$1),0) AS changes`, [userId]);
  if ((rows[0]?.changes ?? 0) >= 2) return res.status(429).json({ error: 'Voting style can only be changed twice per year.' });

  await query(`INSERT INTO core.user_settings (user_id, up_emoji, down_emoji, font_url)
               VALUES ($1,$2,$3,$4)
               ON CONFLICT (user_id) DO UPDATE SET up_emoji=EXCLUDED.up_emoji, down_emoji=EXCLUDED.down_emoji, font_url=EXCLUDED.font_url, updated_at=now()`,
               [userId, p.data.upEmoji, p.data.downEmoji, p.data.fontUrl || null]);
  await query(`INSERT INTO core.settings_change_log (user_id, field) VALUES ($1,'voting')`, [userId]);
  return res.status(204).send();
});
