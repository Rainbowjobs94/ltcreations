<main style={{padding:24}}><h1>Social Universe</h1><a href="/maps">Open Map</a></main>
