
import { useState } from 'react';
export function PostCard({ post, voteStyle }) {
  const [ups,setUps]=useState(post.ups||0); const [downs,setDowns]=useState(post.downs||0); const [myVote,setMyVote]=useState(0);
  const up = voteStyle?.upEmoji || '👍', down = voteStyle?.downEmoji || '👎';
  async function vote(dir){ if(myVote===dir){ await fetch(`http://localhost:3000/v1/posts/${post.id}/vote`,{method:'DELETE'}); if(dir===1)setUps(ups-1); else setDowns(downs-1); setMyVote(0); return; } await fetch(`http://localhost:3000/v1/posts/${post.id}/vote`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({direction:dir})}); if(dir===1){ setUps(ups+1-(myVote===-1?1:0)); if(myVote===-1)setDowns(downs-1); } else { setDowns(downs+1-(myVote===1?1:0)); if(myVote===1)setUps(ups-1);} setMyVote(dir); }
  return (<div style={{position:'relative',border:'1px solid #e5e7eb',borderRadius:16,padding:16,margin:'16px 0'}}>
    <button onClick={()=>vote(-1)} style={{position:'absolute',left:-8,top:'50%',transform:'translate(-100%,-50%)',width:60,height:60,borderRadius:'50%'}}>{down}</button>
    <button onClick={()=>vote(1)} style={{position:'absolute',right:-8,top:'50%',transform:'translate(100%,-50%)',width:60,height:60,borderRadius:'50%'}}>{up}</button>
    <div>{post.snippet}</div><div>{ups} up · {downs} down</div></div>);
}
