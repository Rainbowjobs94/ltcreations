
import { useEffect, useState } from 'react';

export default function VotingSettings(){
  const [upEmoji,setUpEmoji]=useState('👍'); const [downEmoji,setDownEmoji]=useState('👎'); const [fontUrl,setFontUrl]=useState(''); const [remaining,setRemaining]=useState(2);
  useEffect(()=>{ fetch('http://localhost:3000/v1/settings/voting',{headers:{'x-user-id':'1'}}).then(r=>r.json()).then(d=>{ setUpEmoji(d.upEmoji); setDownEmoji(d.downEmoji); setFontUrl(d.fontUrl||''); setRemaining(d.changesRemainingThisYear||2); }); },[]);
  async function save(){ const res = await fetch('http://localhost:3000/v1/settings/voting',{method:'PUT',headers:{'Content-Type':'application/json','x-user-id':'1'},body:JSON.stringify({ upEmoji, downEmoji, fontUrl: fontUrl||undefined })}); if(res.status===204) alert('Saved'); else alert('Error: '+JSON.stringify(await res.json())); }
  return (<main style={{padding:24,fontFamily:'sans-serif'}}><h1>Voting Settings</h1><p>Changes remaining this year: {remaining}</p>
    <div style={{display:'grid',gap:12,maxWidth:420}}>
      <label>Up Emoji <input value={upEmoji} onChange={e=>setUpEmoji(e.target.value)} /></label>
      <label>Down Emoji <input value={downEmoji} onChange={e=>setDownEmoji(e.target.value)} /></label>
      <label>Custom Emoji Font URL <input value={fontUrl} onChange={e=>setFontUrl(e.target.value)} /></label>
      <button onClick={save}>Save</button>
    </div></main>);
}
