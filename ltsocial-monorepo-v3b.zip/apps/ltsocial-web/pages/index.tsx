
import { useEffect, useState } from 'react';
import { PostCard } from '../components/PostCard';
export default function Home(){
  const [posts,setPosts]=useState([]); const [voteStyle,setVoteStyle]=useState({upEmoji:'👍',downEmoji:'👎'});
  useEffect(()=>{ fetch('http://localhost:3000/v1/feed?app=LT&sort=hot').then(r=>r.json()).then(d=>setPosts(d.items||[])); fetch('http://localhost:3000/v1/settings/voting',{headers:{'x-user-id':'1'}}).then(r=>r.json()).then(setVoteStyle); },[]);
  return (<main style={{padding:24,fontFamily:'sans-serif'}}><h1>LTsocial</h1>{posts.map((p:any)=><PostCard key={p.id} post={p} voteStyle={voteStyle}/>)}
    <div style={{marginTop:16}}><a href="/settings/voting">Voting Settings</a></div></main>);
}
