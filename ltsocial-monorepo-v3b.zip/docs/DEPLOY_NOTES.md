
# Deploy notes
- Web: set NEXT_PUBLIC_GOOGLE_MAPS_API_KEY for Social Universe maps.
- Backend: set DATABASE_URL to Postgres; run migrations in order:
  000_base.sql, 005_user_settings.sql, 006_locations.sql
- Android/iOS: copy samples into your native projects and tailor the purpose strings.
